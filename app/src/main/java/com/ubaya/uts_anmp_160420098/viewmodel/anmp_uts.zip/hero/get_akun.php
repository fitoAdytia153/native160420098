<?php
// Set error reporting level
error_reporting(E_ERROR | E_PARSE);

// Establish database connection
$con = new mysqli("localhost", "root", "", "native_uts_160420098");

// Check database connection
if ($con->connect_error) {
    $arrayerror = array('result' => 'Error', 'msg' => 'Failed to connect to the database');
    echo json_encode($arrayerror);
    die();
}

// Get input data from POST request
$inputData = json_decode(file_get_contents("php://input"), true);
$username = $inputData['username'];

// Prepare and execute SQL query to fetch user data
$sql = "SELECT * FROM akun WHERE username=?";
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();

// Get result of the SQL query
$result = $stmt->get_result();

// Fetch user data and store it in an array
$arrayresult = array();
while ($obj = $result->fetch_object()) {
    $arrayresult[] = $obj;
}

// Close the prepared statement
$stmt->close();

// Prepare JSON response
$arrayjson = array(
    'result' => 'OK',
    'data' => $arrayresult
);

// Return JSON response
echo json_encode($arrayjson);
?>
