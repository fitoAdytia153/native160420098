<?php

// Mendapatkan nilai id dari URL
$id = $_GET['id'];

// Menampilkan data pahlawan yang sesuai dengan id
$heroes_json = '[
    {
        "id": 1,
        "name": "Alucard",
        "author": "Moonton",
        "description": "Setelah serangkaian pertempuran yang hebat, Alucard dikenal sebagai salah satu petarung paling legendaris di Moniyan. Setelah itu, semua orang tahu bahwa dimanapun iblis merajalela, pemburu iblis dengan tangan kanan gelap pasti akan turun dari langit dan tidak membiarkan siapapun hidup.",
        "photo_url": "https://wallpaperaccess.com/full/4376476.jpg",
        "skill_name": [
            "Pursuit",
            "Groundsplitter",
            "Whirling Smash",
            "Fission Wave"
        ],
        "skill_description": [
            "Setelah setiap penggunaan skill, Basic Attack Alucard berikutnya membuatnya melompat ke lokasi target dan memberikan (140% Total Physical Attack) Physical Damage.",
            "Alucard melompat ke arah target daan menghantamkan pedangnya ke tanah, memberikan 270 (+110% Extra Physical Attack) Physical Damage ke lawan yang terkena dan menyebabkan 40% Slow selama 2 detik.",
            "Alucard melakukan serangan berputar, memberikan 345 (+120% Extra Physical Attack) Physical Damage kepada lawan di sekitar",
            "Alucard menyerap Hybrid Defense dari lawan di lokasi target dan menyebabkan Slow ke mereka. Gunakan kembali untuk mengeluarkan gelombang serangan ke arah target, memberikan damage ke lawan yang terkena."
        ]
    },
    {
        "id": 2,
        "name": "Balmond",
        "author": "DayHelder",
        "description": "Balmond terlahir ke dalam suku Orc tradisional di dalam Stormeye Wasteland, dan dari usia yang muda ayahnya selalu mengajarinya segala jenis kemampuan bertarung. Bersama dengan ini, dia juga akan menceritakan kisah kejayaan masa lalu para Orc. Dia berharap suatu hari nanti, Balmond dapat menjadi pemimpin Orc sejati dan mengembalikkan mereke kepada kejayaan.",
        "photo_url": "https://publica.id/wp-content/uploads/2022/12/Balmond.jpg",
        "skill_name": [
            "Bloodthrist",
            "Soul Lock",
            "Cyclone Sweep",
            "Lethal Counter"
        ],
        "skill_description": [
            "Balmond memulihkan 5% Max HP setelah mengeliminasi Minion atau Creep, dan 20% Max HP setelah mengeliminasi Hero lawan.",
            "Balmond bergerkan ke arah target, membereikan 150 (+60% Total Physical Attack) Physical Damage ke lawan di jalurnya. Menyebabkan Knockback ke lawan yang terkena dan menyebabkan 60% Slow selama 2 detik.",
            "Balmond mengayunkan kapaknya, memberikan Damage ke lawan di sekitarnya secara terus-menerus. Lawan yang terkena beberapa kali akan menerima Damage yang meningkat.",
            "Balmond melepaskan serangan dahsyat ke arah target (tidak dapat diganggu), memberikan True Damage setara dengan 150 (+70% Total Physical Attack) + 30% HP target yang hilang."
        ]
    },
    {
        "id": 3,
        "name": "Franco",
        "author": "Moonton",
        "description": "Franco berasal dari Frozen Sea di luar daratan Northen Vale. Benua es dan salju ini adalah tempat mata pencaharian bagi para penduduk setempat, namun kebangkitan Kapten Bane telah menghancurkan kehidupan mereka yang sebelumnya damai. Franco dan rekan-rekannya bersatu untuk menentang kekuasaan Bane dan membawa kedamaian kembali ke lautan.",
        "photo_url": "https://esportsku.com/wp-content/uploads/2019/11/Franco.jpg",
        "skill_name": [
            "Wasteland Force",
            "Iron Hook",
            "Fury Shock",
            "Bloody Hunt"
        ],
        "skill_description": [
            "Jika tidak menerima Damage selamat 5 detik, Franco memperoleh 10% Movement Speed tambahan, memulihkan 1% Max HP setiap detik, dan mulai mengakumulasi Wasteland Force (hingga 10 Stack).",
            "Franco melemparkan Iron Hook ke ara target. Iron Hook akan menangkap unit lawan pertama yang terkena, memberikan 400(+100% Total Physical Attack) Physical Damage dan menarik mereka ke Franco.",
            "Franco melampiaskan amarahnya, memberikan Physical Damage setara dengan 300 + 4% Max HP-nya kepada lawan di sekitar dan menyebabkan efek Slow kepada mereka sebesar 70% selama 1.5 detik.",
            "Franco menyebabkan Suppress ke Hero lawan selamat 1.8 detik dan menyerang mereka 6 kali selama durasi skill, memberikan 50(+70% Total Physical Attack) Physical Damage dengan setiap serangan."
        ]
    },
    {
        "id": 4,
        "name": "Kaja",
        "author": "Rhapsody",
        "description": "Sebagai pemimpin, Kaja mampu memperbaiki kekuatan cahaya menjadi energi murni untuk mengendalikan apa yang diinginkannya, menimbulkan kerusakan yang sangat besar bagi semua lawan yang menghadapinya, dan ditugaskan untuk melindungi penguasa kota secara langsung.",
        "photo_url": "https://1.bp.blogspot.com/-q-6Hy7xPE7g/Xst2udr1tlI/AAAAAAAAClQ/KOQC_PuYW1sNZI_vP8wTptG82H36u2VzgCLcBGAsYHQ/s1600/wallpaper-kaja-horror-whiplash-skin-mobile-legends-full-hd-for-pc-hobigame.jpg",
        "skill_name": [
            "Wrath Sacntion",
            "Ring of Order",
            "Lightning Bomb",
            "Divine Judgement"
        ],
        "skill_description": [
            "Kaja memperoleh Wrath Sanction setiap 6 detik. Basic Attack berikutnya akan mengeluarkan petir pada lawan, memberikan Magic Damage yang setara dengan 100 (+100% Total Magic Power) + 4% Max HP target dan menyebabkan Paralyze ke mereka.",
            "Kaja mengeluarkan Ringed Electric Blade, memberikan 135 (+70% Total Magic Power) Magic Damage dan menyebabkan efek Paralyze kepada lawan yang terkena. Serangan ini juga mengungkapkan posisi lawan yang terkena secara singkat. Setiap kali Ringed Electric Blade memberikan Damage, Kaja memulihkan 100 HP (berkurang menjadi 30% setelah mengenai lebih dari 1 kali).",
            "Kaja bergerak ke arah yang ditentukan sambil meninggalkan 3 Lightning Bomb di sepanjang jalurnya. Lightning Bomb akan meledak saat mengenai lawan, memberikan 150 (+35% Total Magic Power) Magic Damage kepada lawan dan menyebabkan efek Paralyze kepada mereka.",
            "Kaja memberikan 200 (+100% Total Magic Power) Magic Damage ke Hero lawan yang ditentukan, menyebabkan Suppress dan Paralyze selama 1.5 detik. selama Suppress berlangsung, Kaja dapat menyeret lawan bersamanya."
        ]
    },
    {
        "id": 5,
        "name": "Cici",
        "author": "Moonton",
        "description": "Lihatlah, bintang pertunjukan yang mempesona itu!! Oh, betapa aku masih sangat terkesima! Mari kita sambut gadis yang bermain - main di awan, melintasi atap rumah, dan di tengah padang rumput. Dari tangannya, Yoyo, rekannya yang berputar, melambung tinggi ke angkasa, menyulut pertunjukkan kembang api yang menghujani langit dan membuat setiap mata terpukau.",
        "photo_url": "https://tse1.mm.bing.net/th/id/OIP.MvckcMDkW-qv_rQueSbkOwHaD5?w=828&h=435&rs=1&pid=ImgDetMain",
        "skill_name": [
            "Performers Delight",
            "Yo-Yo Blitz",
            "Buoyant Bounce",
            "Curtain Call"
        ],
        "skill_description": [
            "Cici menghasilkan satu Stack Delight setelah memberikan Damage, setiap Stack meningkatkan 0.75% Movement Speed dan 0.75% Spell Vamp-nya hingga 10 kali, efek menjadi dua kali lipat saat Stack penuh.",
            "Cici menggunakan Yoyo untuk terus menyerang lawan terdekat dalam jangkauan (memprioritaskan Hero) selama 3.5 detik, menyerang mereka hingga 10 kali, dan memberikan Physical Damage setara dengan 60 + 3 (+1.2% Extra Physical Attack)% Max HP target di setiap serangan. Cici dapat bergerak dan menggunakan Skill lainnya saat serangan ini berlangsung.",
            "Cici melompat ke lokasi target. Jika dia mendarat ke unit apa pun (tidak termasuk Turret dan Base), dia dapat melompat kembali sesuai arah Joystick. Jika dia mendarat ke lawan pada lompatan pertama, dia memberikan 200 (+40% Total Physical Attack) Physical Damage ke mereka.",
            "Cici melemparkan Yoyo ke Hero lawan dan menghubungkan mereke dengan Hero lain di sekitar, memberikan 100 (+10% Total Physical Attack) Physical Damage, menyebabkan 30% Slow, dan menarik mereka mendekat selama 4 detik. Selama durasi ini, Cici dapat menggunakan Yo-Yo Blitz untuk menyerang kedua target yang terhubung di saat bersamaan. Jika hanya ada satu target dalam jangkauan Yo-Yo Blitz, Cici akan menyerang target dua kali, tapi Damage serangan kedua akan berkurang menjadi 20%."
        ]
    },
    {
        "id": 6,
        "name": "Estes",
        "author": "JuanWapak",
        "description": "Raja Elf di generasi ini adalah Estes yang unik, yang terluka parah saat Perang Wilayah kedua dan harus jatuh ke dalam tidur yang lelap di Emerald Woodland. Sejak saat itu, para Moon Elf kehilangan tuntunan dari rajanya. Saat peperangan membara di antara manusia dan Orc di Emerald Woodland yang damai ini, sang Moonlight Archer muda, Miya, maju dan mengumpulkan Elf yang tersisa untuk melindungi kampung halaman mereka.",
        "photo_url": "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhDYq8uTIosBk7fZymVIrgwuJMUzImc2VH3w2A_CPDL9MPW4Y9ZCh-LIJs8Xe2vlyrzHrpLcaiN9_EEy26d5bHMv8GQJkiK0rK_XPiV2aPewkCEazzWZq1VbYX8qwgVskTzms5dPUVWuDdoCwQVn4KETY_QKHwIdc3NowCG9_HGBx0k3XkSPVEPsn_ZBA/s4320/estes-galaxy-dominator-epic-skin-wallpaper-hd.jpg",
        "skill_name": [
            "Scripture of the Moon Elf",
            "Moonlight Immersion",
            "Domain of Moon Goddess",
            "FBlessing of Moon Goddess"
        ],
        "skill_description": [
            "Scripture of the Moon Elf secara perlahan mengisi energi Estes. Saat mencapai 100 Stack, Basic Attack berikutnya akan diperkuat, memberikan 250 (+100%Total Physical Attack) (+150%Total Magic Power) Magic Damage ke target dan 125 (+50%Total Physical Attack) (+75%Total Magic Power) Magic Damage ke lawan di dekatnya, serta menyebabkan 60% Slow selama 1.5 detik.",
            "Estes memulihkan 250 (+110%Total Magic Power) HP untuk Hero rekan tim secara langsung dan menghubungkan dirinya dengan target selama 3 detik, memulihkan 325 (+60%Total Magic Power) HP untuk target secara perlahan. Terhubung dengan Hero satu tim juga akan meningkatkan 20 Hybrid Defense Estes dan 15% Movement Speed, serta meningkatkan kecepatan pengumpulan energi dari Scripture of the Moon Elf. Bergerak terlalu jauh dari target akan memutuskan hubungan.",
            "Estes menjatuhkan cahaya rembulan ke area target, memberikan 350 (+70%Total Magic Power) Magic Damage ke unit lawan di dalamnya. Setelah itu, cahaya berubah menjadi Domain of the Moon Goddess dan mengungkapkan lawan di dalamnya. Lawan akan terkena 90% Slow selama 1.5 detik jika mereka menyentuh tepi area Domain. (Efek Slow akan berkurang seiring waktu)",
            "Estes memberikan Moonlight Immersion yang diperkuat ke semua Hero rekan tim di sekitarnya. Dalam 8 detik berikutnya, Moonlight Immersion akan diperkuat dan Estes akan terus memulihkan 1230 (+210%Total Magic Power) HP."
        ]
    },
    {
        "id": 7,
        "name": "Rafaela",
        "author": "SayukiSo",
        "description": "Argus dan Rafaela adalah saudara kembar yang lahir di Moniyan Empire. Sacrist Monastery of Light memaksa ibu mereka untuk meminum air suci, atas nama Lord of Light. Oleh karna itu, dia mengandung sesosok malaikat di dalam kuil Lord of Light. Ibu mereka hanyalah seorang wanita biasa, dia dan kekasihnya saling setia satu sama lain. Namun di bawah pengawasan dan bujukan dari para Sacrist, dia tidak dapat berbuat apa-apa selain menerima kehormatan yang dianugerahkan kepadanya oleh Lord of Light.",
        "photo_url": "https://i.pinimg.com/originals/f1/02/f5/f102f588562785bce48f0ab7ef0d48fa.jpg",
        "skill_name": [
            "Deity Penalization",
            "Light of Retribution",
            "Holy Healing",
            "Holy Baptism"
        ],
        "skill_description": [
            "Saat tereliminasi, Rafaela berubah menjadi Holy Light dan menyerang ke lawan yang mengeliminasinya setelah jeda selama 2 detik. Serangan ini memberikan True Damage yang setara dengan 20% dari Max HP target yang terkena dan dapat dihalangi oleh Hero lawan lainnya, memberikan Damage ke mereka. Efek ini tidak akan aktif jika yang mengeliminasi adalah lawan Non-Hero atau jika jarak lawan terlalu jauh.",
            "Rafaela menyerang tiga lawan terdekat dengan Light of Retribution, memberikan 225 (+120%Total Magic Power) Magic Damage ke mereka, memperlihatkan posisi mereka secara singkat, dan menyebabkan 40% Slow selama 1.5 detik. Lawan yang terkena Light of Retribution kembali dalam 5 detik akan menerima 20% Damage tambahan (efek ini dapat di-Stack hingga 3 kali).",
            "Rafaela memanggil Holy Light, memulihkan 100 (+35%Total Magic Power) HP untuk Hero rekan di sekitar, serta 150 (+45%Total Magic Power) HP tambahan ke dirinya dan Hero rekan dengan HP terendah di jangkauan. Selain itu, meningkatkan 30% Movement Speed Hero rekan di sekitar dan memberikan kebal Slow selama 1 detik. Setiap 20 Magic Power akan menambahkan 1% bonus Movement Speed.",
            "Rafaela menggunakan kekuatan Holy Light yang sesungguhnya ke arah target, memberikan 460 (+120%Total Magic Power) Magic Damage ke lawan di jalur dan menyebabkan Stun ke mereka selama 1.2 detik."
        ]
    },
    {
        "id": 8,
        "name": "Floryn",
        "author": "Sakusa",
        "description": "Sejak lahir, Floryn tidak pernah keluar dari Oasis. Mereka mengasingkannya dari lingkungan gurun yang mengerikan, agar dia menjalani kehidupan tanpa beban. Bagi Floryn, benih bercahaya itu adalah satu-satunya misteri dalam hidupnya yang damai. Dia menghabiskan hari-harinya merenungkan rahasia benih. Hanya penjelajah dan karavan yang sesekali mengunjungi dunia kecil ini.",
        "photo_url": "https://dafunda.com/wp-content/uploads/2022/05/Hero-Floryn-Mobile-Legends.jpg",
        "skill_name": [
            "Dew",
            "Sow",
            "Sprout",
            "Bloom"
        ],
        "skill_description": [
            "Lentera milik Dew sedikit meningkatkan atribut Floryn secara permanen. Setelah meninggalkan pertarungan selama 5 detik, Floryn dapat membagikan Flower of Hope ke Hero rekan tim (Cooldown 30 detik), serta memberikan 150 (+80%Total Magic Power) Shield setiap kali mereka menerima pemulihan dari Floryn.",
            "Floryn melemparkan Benih Energi ke target, memberikan 180 (+100%Total Magic Power) Magic Damage. Kemudian Buah Pemulihan akan muncul dan memantul ke Hero rekan tim terdekat, memulihkan 175 (+90%Total Magic Power) HP mereka.",
            "Floryn melemparkan gumpalan energi yang meledak saat mengenai lawan, memberikan 175 (+90%Total Magic Power) Magic Damage ke lawan di sekitar dan menyebabkan Stun selama 0.7 detik (serta mengungkapkan posisi mereka secara singkat).",
            "Floryn beresonansi dengan kekuatan Dew, memulihkan 250 (+100%Total Magic Power) HP ke semua Hero rekan tim 2 kali di mana pun mereka berada di Battlefield. Efek ini juga menghapus efek Pengurangan Pemulihan atau Shield pada Hero rekan tim, dan membuat mereka menjadi kebal terhadap efek tersebut selama 2 detik."
        ]
    },
    {
        "id": 9,
        "name": "Arlott",
        "author": "Moonton",
        "description": "Jalan ini terpisah menjadi tiga jalan yang berbeda. Di selatan ada Barren Lands. Di utara, Lumina City, tempat yang dia tinggalkan. Bintang-bintang di langit pun bersinar di atasnya. Setahun sebelumnya, dia berbaring di rumput dan memandangi bintang-bintang yang sama. Seorang manusia setengah iblis yang tidak dapat menemukan jati dirinya. Dia pun memutuskan menjadi anak buah Alice yang pada akhirnya dia dikhianati dan diselamatkan oleh seorang gadis kecil. Melihat kesungguhan hati gadis kecil tersebut membuat Arlott mulai tahu siapa dirinya dan untuk apa dia hidup.",
        "photo_url": "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiGZRo1vbEvtFm-Mh30gsOYt6WuqOqb9A0wwqA4oUFu3OUnKg9NURoUr9ukNsW6t1uEVsa4uPhIbbUEvFFlnvW167dnfAtZknyLi8ntqfpn2krtnsvVTCdHCFm4aEak80BdO-35zbLmZaYdHklqWHQZLmxAwZN3XpqiRktTgxZtDGNSHVvxoLkHvmL0fQ/s3840/arlott-wandering-lance-basic-skin-wallpaper-hd.jpg",
        "skill_name": [
            "Demon Gaze",
            "Dauntless Strike",
            "Vengeance",
            "Final Slash"
        ],
        "skill_description": [
            "Arlott memiliki mata iblis yang meninggalkan Mark ke unit lawan di sekitar Arlott yang terkena Crowd Control selama 8 detik. Mata tersebut juga meninggalkan Mark ke Hero lawan di sekitar secara otomatis setiap 8 detik.",
            "Arlott mengayunkan tombaknya ke depan, memberikan 200 (+60%Total Physical Attack) Physical Damage menyebabkan Stun singkat kepada target di area. Target yang terkena bagian jauh dari area efek akan terkena Stun selama 1 detik sebagai gantinya.",
            "Arlott menyerang lawan, memberikan 135 (+60%Total Physical Attack) Physical Damage (Skill ini tidak dapat dihentikan ketika bergerak). Jika target Arlott memiliki Mark, Skill ini memberikan Damage ganda, langsung mereset Cooldown-nya, dan memulihkan (90%Total Physical Attack) HP Arlott (hanya memulihkan 50% dari jumlah tersebut jika digunakan ke unit non-Hero).",
            "Arlott menebas ke depannya, memberikan 400 (+80%Total Physical Attack) Physical Damage kepada target di dalam area sambil mendorong mereka ke ujung Area Efek dan mengungkap posisi mereka dalam waktu singkat."
        ]
    },
    {
        "id": 10,
        "name": "Miya",
        "author": "LaosK",
        "description": "Miya berdiri di puncak pepohonan dan mengintai serangan musuh. Sekelompok pasukan Orc dan iblis menerobos perbatasan, menyebabkan kerusakan pada Lunar Aegis dan membuat Pohon Kehidupan berguncang. Dengan tarikan busur panahnya, tiga sinar cahaya bulan keperakan yang berkilau melenggang anggun melalui ranting-ranting sebelum dengan cepat membunuh pemimpin pasukan itu dan membuat para iblis berlarian dalam kekacauan. Dengan hilangnya ancaman, para Elf menyalurkan energi dari Pohon Kehidupan untuk memperbaiki kerusakan dan memulihkan Lunar Aegis. Kedamaian kembali ke hutan dan semuanya baik-baik saja.",
        "photo_url": "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/a44778ea-3457-40e0-8979-b7e3685d23d0/dfbnvlb-fc63458c-ce30-4430-b2a1-af494174ca64.png/v1/fill/w_1920,h_1074,q_80,strp/miya_collector_skin_8k_wallpaper_by_newjer53_dfbnvlb-fullview.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTA3NCIsInBhdGgiOiJcL2ZcL2E0NDc3OGVhLTM0NTctNDBlMC04OTc5LWI3ZTM2ODVkMjNkMFwvZGZibnZsYi1mYzYzNDU4Yy1jZTMwLTQ0MzAtYjJhMS1hZjQ5NDE3NGNhNjQucG5nIiwid2lkdGgiOiI8PTE5MjAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.xaSAApjkCQU53FdmRBuoozg_6Euo9yS1q2ik9TjN7gA",
        "skill_name": [
            "Moon Blessing",
            "Moon Arrow",
            "Arrow of Eclipse",
            "Hidden Moonlight"
        ],
        "skill_description": [
            "Setiap kali Basic Attack Miya mengenai target, dia memperoleh 5% Attack Speed selama 4 detik. Dapat di-Stack hingga 5 kali. Setelah Stack penuh, Miya memanggil Moonlight Shadow di setiap Basic Attack yang memberikan 30 (+30%Total Physical Attack) Physical Damage dan mewarisi sebagian Efek Basic Attack.",
            "Miya menembakkan dua anak panah tambahan di setiap Basic Attack, memberikan 10 (+100%Total Physical Attack) Physical Damage ke target dan 30% Damage ke target di sekitar. Efek ini berlangsung selama 4 detik. Setiap anak panah tambahan mewarisi sebagian Efek Basic Attack",
            "Miya menembakkan anak panah yang diperkuat ke area yang ditentukan, memberikan 270 (+45%Total Physical Attack) Physical Damage dan menyebabkan efek Immobilize kepada lawan di area selama 1.2 detik. Kemudian anak panah terbagi menjadi 6 anak panah kecil yang menyebar setiap anak panah memberikan 40 (+20%Total Physical Attack) Physical Damage kepada lawan pertama yang terkena Hit dan menyebabkan efek Slow kepada mereka sebesar 30% selama 2 detik.",
            "Miya menghapus semua Debuff pada dirinya dan memasuki Mode Conceal, memperoleh 35% Movement Speed tambahan. Mode ini berlangsung selama 2 detik atau hingga dia melakukan serangan. Miya memperoleh Stack penuh dari Moon Blessing saat Mode Conceal berakhir."
        ]
    }
]';

$heroes_data = json_decode($heroes_json, true);

foreach ($heroes_data as $hero) {
    if ($hero['id'] == $id) {
        // Menampilkan data pahlawan
        echo json_encode($hero);
        break;
    }
}

?>