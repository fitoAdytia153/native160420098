<?php
error_reporting(E_ERROR | E_PARSE);

$host = "localhost"; 
$dbname = "native_uts_160420098";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
}
// Ambil dan sanitasi input
$username = $conn->real_escape_string($_POST['username']);
$password = $_POST['password'];

if (empty($username) || empty($password)) {
    echo json_encode(['status' => 'error', 'message' => 'Username and password are required']);
    exit;
}

// Query ke database untuk mendapatkan data user
$query = $conn->prepare("SELECT username, nama_depan, nama_belakang, password FROM akun WHERE username = ?");
$query->bind_param("s", $username);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    // Verifikasi password
    if (password_verify($password, $user['password'])) {
        // Prepare data to send back
        $account = [
            'username' => $user['username'],
            'nama_depan' => $user['nama_depan'],
            'nama_belakang' => $user['nama_belakang'],
            'password' => $user['password']
        ];
        echo json_encode(['status' => 'success', 'message' => 'Login successful', 'account' => $account]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid password']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Username not found']);
}

$query->close();
$conn->close();
?>