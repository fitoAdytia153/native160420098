<?php
error_reporting(E_ERROR | E_PARSE);

$host = "localhost"; 
$userDB = "root";
$passDB = ""; 
$dbname = "native_uts_160420098";

// Membuat koneksi ke database
$conn = new mysqli($host, $userDB, $passDB, $dbname);

// Mengecek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$namaDepan = $_POST['namaDepan'];
$namaBelakang = $_POST['namaBelakang'];
$user = $_POST['user'];
$pass = $_POST['pass'];


// Menggunakan password_hash untuk hashing password
$hashedPassword = password_hash($pass, PASSWORD_DEFAULT);

$query = "INSERT INTO akun (nama_depan, nama_belakang, username, password) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    exit;
}

// Bind parameter ke statement
$bind = $stmt->bind_param("ssss", $namaDepan, $namaBelakang, $user, $hashedPassword);
if (!$bind) {
    echo "Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error;
    exit;
}

if ($stmt->execute()) {
    echo json_encode(['message' => 'User registered successfully']);
} else {
    echo json_encode(['message' => 'User registration failed', 'error' => $stmt->error]);
}

// Menutup statement dan koneksi
$stmt->close();
$conn->close();
?>