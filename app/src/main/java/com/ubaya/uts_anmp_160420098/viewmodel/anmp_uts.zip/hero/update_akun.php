<?php

error_reporting(E_ERROR | E_PARSE);
$conn = new mysqli("localhost", "root", "", "native_uts_160420098");
if ($conn->connect_error) {
    die(json_encode(array('result' => 'ERROR', 'Message' => 'Failed to connect to DB' . $conn->connect_error)));
} else {
    $username = $_POST['username'];
    $namaDepan = $_POST['nama_depan'];
    $namaBelakang = $_POST['nama_belakang'];
    $password = isset($_POST['password']) ? $_POST['password'] : null;
}

if (!empty($password)) {
    $password = password_hash($password, PASSWORD_DEFAULT);
    $query = $conn->prepare("UPDATE akun SET nama_depan = ?, nama_belakang = ?, password = ? WHERE username = ?");
    $query->bind_param("ssss", $namaDepan, $namaBelakang, $password, $username);
} else {
    $query = $conn->prepare("UPDATE akun SET nama_depan = ?, nama_belakang = ? WHERE username = ?");
    $query->bind_param("sss", $namaDepan, $namaBelakang, $username);
}

$result = $query->execute();

if ($result) {
    echo json_encode(['status' => 'success', 'message' => 'User updated successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Update failed: ' . $query->error]);
}

$query->close();
$conn->close();
?>